#!/bin/bash

failures=0
ghc CatPlus

runtest ()
{
    if [ ! -f TestFiles/${1}.input ]; then
	echo "${1} Failed: input file not found!"
	return 1
	exit
    elif [ ! -f TestFiles/${1}.output ]; then
	echo "${1} Failed: output file not found!"
	return 1
	exit
    fi

    TestOutput=$(./CatPlus ${2} TestFiles/${1}.input |
		 diff TestFiles/${1}.output -)

    if [ -z "$TestOutput" ]; then
	echo "${1} Passed."
    else
	echo "${1} Failed: comparision failed!"
	return 1
    fi
    return 0
}

# Test Non Printing Characters
runtest "NonPrintableTest" "-v"
failures=$(( $failures + $? ))

# Test Tabs
runtest "TabTest" "-t"
failures=$(( $failures + $? ))

# Test Tabs and Non-Printing Characters
runtest "TabsNonPrintableTest" "-t"
failures=$(( $failures + $? ))

# Test Dollar End of Line
runtest "DollarTest" "-e"
failures=$(( $failures + $? ))

# Test Dollar End of Line and Non-Printables
runtest "DollarNonPrintableTest" "-e"
failures=$(( $failures + $? ))

# Test Numbering All lines
runtest "NumberAllTest" "-n"
failures=$(( $failures + $? ))

# Test Numbering non-blank lines
runtest "NumberSomeTest" "-b"
failures=$(( $failures + $? ))

# Test Squeezing
runtest "SqueezeTest" "-s"
failures=$(( $failures + $? ))

# Test Left Align
runtest "LeftAlignTest" "-l 80"
failures=$(( $failures + $? ))

# Test Left Align
runtest "LeftAlignTest" "-l 80"
failures=$(( $failures + $? ))

# Test Left Align and Fill
runtest "LeftAlignFillTest" "-f -l 80"
failures=$(( $failures + $? ))

# Test Left Align and Indent
runtest "LeftAlignIndentTest" "-i -l 80"
failures=$(( $failures + $? ))

# Test Left Align, Indent, and Fill
runtest "LeftAlignIndentFillTest" "-i -f -l 80"
failures=$(( $failures + $? ))

# Test Right Align
runtest "RightAlignTest" "-r 80"
failures=$(( $failures + $? ))

# Test Center Align
runtest "CenterAlignTest" "-c 80"
failures=$(( $failures + $? ))

# Test Center Align and Fill
runtest "CenterAlignFillTest" "-f -c 80"
failures=$(( $failures + $? ))

# Test Justify
runtest "JustifyTest" "-j 80"
failures=$(( $failures + $? ))

# Test Justify and Fill
runtest "JustifyFillTest" "-f -j 80"
failures=$(( $failures + $? ))

# Test Justify and Indent
runtest "JustifyIndentTest" "-i -j 80"
failures=$(( $failures + $? ))

# Test Justify, Indent, and Fill
runtest "JustifyIndentFillTest" "-i -k -f -l 80"
failures=$(( $failures + $? ))


echo "====================="
echo
if [ $failures -eq 0 ]; then
    echo "All tests Passed!"
else
    echo "Failed $failures tests."
fi
