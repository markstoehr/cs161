import CatLibrary
import CatFlagLibrary
import Control.Monad
import Data.Char
import Data.List
import System.Console.GetOpt
import System.Environment
import System.Exit
import System.IO

main :: IO ()
main = do
     (catOptions, files) <- getArgs >>= parse
     when (displayUnbuffered catOptions) $ hSetBuffering stdout NoBuffering
     mapM_ (catPlus catOptions) files

-- parse the flags
parse :: [String] -> IO (CatOptions, [[Char]])
parse argv = case getOpt Permute flags argv of
    (args, fs, []) -> do
        let files = if null fs then ["-"] else fs
        if Help `elem` args
            then do hPutStrLn stderr (usageInfo catHeader flags)
                    exitWith ExitSuccess
            else return (catFlagListToCatOptions args, files)
    
    (_, _, errs)  -> do
        hPutStrLn stderr (concat errs ++ usageInfo catHeader flags)
        exitWith (ExitFailure 1)
