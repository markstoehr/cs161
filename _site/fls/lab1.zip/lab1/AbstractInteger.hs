module AbstractInteger (
       AbstractNatural(Zero, S),
successor,
negator,
absolute,
predecessor,
add,
difference,
multiply,
divide,
modulo,
toAbstract,
fromAbstract,
solveRPN,
  one,
  two,
  three,
  four,
  five,
  six,
  seven,
  eight,
  nine,
  ten,
  negative_one,
  negative_two,
  negative_three,
  negative_four,
  negative_five,
  negative_six,
  negative_seven,
  negative_eight,
  negative_nine,
  negative_ten) where

data AbstractNatural = Zero | S AbstractNatural
  deriving (Show)

instance Eq AbstractNatural where
  Zero == Zero = True
  Zero == S y  = False
  S x  == Zero = False
  S x  == S y  = x == y

instance Ord AbstractNatural where
  Zero <= Zero = True
  Zero <= S y  = True
  S x  <= Zero = False
  S x  <= S y  = x <= y

successor = S
predecessor Zero = Zero
predecessor (S x) = x
negator = undefined
absolute = undefined
add = undefined
difference = undefined
multiply = undefined
divide = undefined
modulo = undefined
toAbstract = undefined
fromAbstract = undefined

solveRPN :: [String] -> Integer
solveRPN  = fromAbstract . head . foldl foldingFunction []
  where
    foldingFunction (x:y:ys) "*" = (multiply x y):ys
    foldingFunction (x:y:ys) "+" = (add x y):ys
    foldingFunction (x:xs) "abs" = (absolute x):xs
    foldingFunction xs numberString =
      (toAbstract $ (read (numberString :: String) :: Integer)):xs


one = successor Zero
two = successor one
three = successor two
four = successor three
five = successor four
six = successor five
seven = successor six
eight = successor seven
nine = successor eight
ten = successor nine
negative_one = predecessor Zero
negative_two = predecessor negative_one
negative_three = predecessor negative_two
negative_four = predecessor negative_three       
negative_five = predecessor negative_four
negative_six = predecessor negative_five
negative_seven = predecessor negative_six
negative_eight = predecessor negative_seven       
negative_nine = predecessor negative_eight
negative_ten = predecessor negative_nine       

