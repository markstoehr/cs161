import AbstractInteger
import Test.QuickCheck

prop_convertbijection :: Integer -> Bool
prop_convertbijection x = x == fromAbstract (toAbstract x)

prop_successor_succeeds :: Integer -> Bool
prop_successor_succeeds x = successor (toAbstract x) == toAbstract (1 + x)

prop_negation x = negator (toAbstract x) == toAbstract (- x)

prop_predecessor_precedes x = predecessor (toAbstract x) == toAbstract (x - 1)

prop_adder_adds x y = add (toAbstract x) (toAbstract y) ==
                      toAbstract (x + y)
                      
prop_differencer_differences x y = difference
                                   (toAbstract x)
                                   (toAbstract y) ==
                                   toAbstract (x - y)
                               
prop_multiplier_multiplies x y = multiply (toAbstract x)
                                 (toAbstract y) ==
                                 toAbstract (x * y)

testRPN1 = solveRPN ["3", "4", "-", "2", "+", "10", "*"] == toAbstract 10

main = do
  putStrLn "Testing bijection for types"
  quickCheck prop_convertbijection
  quickCheck prop_successor_succeeds
  quickCheck testRPN1
                               
