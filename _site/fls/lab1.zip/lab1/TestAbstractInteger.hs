import AbstractInteger
import Test.QuickCheck

prop_convertbijection :: Integer -> Bool
prop_convertbijection x = x == abstractToInt (convertToAbstract x)

prop_successor_succeeds :: Integer -> Bool
prop_successor_succeeds x = successor (convertToAbstract x) == convertToAbstract (1 + x)

prop_negation x = negator (convertToAbstract x) == convertToAbstract (- x)

prop_predecessor_precedes x = predecessor (convertToAbstract x) == convertToAbstract (x - 1)

prop_adder_adds x y = add (convertToAbstract x) (convertToAbstract y) ==
                      convertToAbstract (x + y)
                      
prop_differencer_differences x y = difference
                                   (convertToAbstract x)
                                   (convertToAbstract y) ==
                                   convertToAbstract (x - y)
                               
prop_multiplier_multiplies x y = multiply (convertToAbstract x)
                                 (convertToAbstract y) ==
                                 convertToAbstract (x * y)

testRPN1 = solveRPN ["3", "4", "-", "2", "+", "10", "*"] == convertToAbstract 10

main = do
  putStrLn "Testing bijection for types"
  quickCheck prop_convertbijection
  quickCheck prop_successor_succeeds
  quickCheck testRPN1
                               
