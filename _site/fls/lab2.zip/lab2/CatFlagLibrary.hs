module CatFlagLibrary (
  Flag(
    Blanks,
    Dollar,
    Squeeze,
    Tabs,
    Unbuffered,
    Invisible,
    Number,
    LeftAlign,
    Help),
  CatOptions(
    displayNonBlankCount,
    displayLineNumbers,
    displayLineTerminators,
    suppressMultipleBlank,
    displayVisibleTab,
    displayVisibleNonPrinting,
    displayUnbuffered,
    doLeftAlign,
    columnWidth),
  catFlagListToCatOptions,
  catHeader,
  flags) where

import Data.List
import System.Console.GetOpt
import System.Environment
import System.Exit
import System.IO


-- Define flag value enumeration 
-- deriving semantics: see https://www.haskell.org/onlinereport/derived.html
data Flag
     = Blanks
     | Dollar
     | Squeeze
     | Tabs
     | Unbuffered
     | Invisible
     | Number
     | LeftAlign Integer
     | Help
     deriving (Eq, Show)

catHeader :: String
catHeader = "Usage: cat [-benstuv] [-l K] [file ...]"

-- binding command flags
flags :: [OptDescr Flag]
flags =
      [Option ['b'] []           (NoArg Blanks)
              "Implies the -n option but doesn't count blank lines.",
       Option ['e'] []           (NoArg Dollar)
              "Implies the -v option and also prints a `$` at the end of each \
              \line.",
       Option ['n'] []           (NoArg Number)
              "Number the output lines, starting at 1.",
       Option ['s'] []           (NoArg Squeeze)
              "Squeeze multiple adjacent empty lines, causing the output to be \
              \single spaced.",
       Option ['t'] []           (NoArg Tabs)
              "Implies the -v option and also prints tab characters as `^I'.",
       Option ['u'] []           (NoArg Unbuffered)
              "The output is guaranteed to be unbuffered (see setbuf(3)).",
       Option ['v'] []           (NoArg Invisible)
              "Displays non-printing characters so they are visible.",
       Option ['l'] ["integer"]
              (ReqArg (LeftAlign . read) "WIDTH")
              "Left align each paragraph with a particular column width.",
       Option []    ["help"] (NoArg Help)
              "Print this help message"
      ]

-- Pass flag data around easily
data CatOptions = CatOptions
  { displayNonBlankCount :: Bool,
    displayLineNumbers :: Bool,
    displayLineTerminators :: Bool,
    suppressMultipleBlank :: Bool,
    displayVisibleTab :: Bool,
    displayVisibleNonPrinting :: Bool,
    displayUnbuffered :: Bool,
    doLeftAlign :: Bool,
    columnWidth :: Integer
  } deriving (Show, Eq)

-- convert a list of flags to a catOptions record
catFlagListToCatOptions :: [Flag] -> CatOptions
catFlagListToCatOptions = foldl catSetOption catOptionsDefault

catOptionsDefault :: CatOptions
catOptionsDefault = CatOptions { displayNonBlankCount = False,
                                 displayLineNumbers = False,
                                 displayLineTerminators = False,
                                 suppressMultipleBlank = False,
                                 displayVisibleTab = False,
                                 displayVisibleNonPrinting = False,
                                 displayUnbuffered = False,
                                 doLeftAlign = False,
                                 columnWidth = 80 }

catSetOption :: CatOptions -> Flag -> CatOptions
catSetOption catOptions flag = case flag of
  Blanks          -> flip catSetOption Number
                     catOptions { displayNonBlankCount = True }
  Dollar          -> flip catSetOption Invisible
                     catOptions { displayLineTerminators = True }
  Number          -> catOptions { displayLineNumbers = True }
  Squeeze         -> catOptions { suppressMultipleBlank = True }
  Tabs            -> flip catSetOption Invisible
                     catOptions { displayVisibleTab = True }
  Unbuffered      -> catOptions { displayUnbuffered = True }
  Invisible       -> catOptions { displayVisibleNonPrinting = True }
  LeftAlign width -> catOptions { doLeftAlign = True, columnWidth = width }
