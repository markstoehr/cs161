module CatLibrary (catPlus) where

import CatFlagLibrary
import Control.Monad
import Data.List
import Data.Char
import System.Console.GetOpt
import System.Environment
import System.Exit
import System.IO
import Text.Printf

-- take a filename, open it, apply processing pipeline
processFile :: String -> ([String] -> [String]) -> IO ()
processFile filename pipeline =
  putStr . unlines . pipeline . lines =<< open filename
  where
    open "-" = getContents
    open filename = readFile filename

-- apply arguments to filename
catPlus :: CatOptions -> String -> IO ()
catPlus catOptions filename = processFile filename pipeline
  where
    number = if displayNonBlankCount catOptions
                then numberSome
                else if displayLineNumbers catOptions
                        then numberAll
                        else id
    ends = if displayLineTerminators catOptions then dollarEnds else id
    codes = if displayVisibleNonPrinting catOptions then showCodes else id
    squeeze = if suppressMultipleBlank catOptions then squeezeBlank else id
    tabs = if displayVisibleTab catOptions then showTabs else id
    pipeline = codes . number . ends . tabs . squeeze

-- converts an integer and a string into a string
numberLine :: Integer -> String -> String
numberLine = printf "%6d  %s"

-- number all lines
numberAll = zipWith numberLine [(1 :: Integer)..]

-- do not number blank lines
numberSome   = undefined

-- put a `$` at the end of each line
dollarEnds   = undefined

-- display non-printing characters
showCodes = map $ concatMap visible
  where
    visible c | c == '\t' || isPrint c = [c]
              | otherwise              = init . tail . show $ c

-- display tabs
showTabs     = map $ concatMap (\c -> if c == '\t' then "^I" else [c])

squeezeBlank = undefined


